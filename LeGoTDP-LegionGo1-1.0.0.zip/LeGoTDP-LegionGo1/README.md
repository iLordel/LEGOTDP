# LeGoTDP — Legion Go 1

Управление TDP для **оригинального Lenovo Legion Go (83E1, Ryzen Z1 Extreme)**
прямо из Steam Gaming Mode, через Decky Loader.

Это форк [LeGoTDP](https://github.com/Rayekkk/LeGoTDP) (сборка для Legion Go 2 /
Legion Go S), адаптированный под первый Legion Go: собственный профиль
устройства, собственные диапазоны, собственная лестница пресетов и третий
бэкенд — `acpi_call`, потому что на ядрах, которые сейчас ставит SteamOS,
драйвера Lenovo WMI ещё нет.

---

## Что именно сделано под Go 1

| | Legion Go 1 (этот форк) | Legion Go 2 / Go S (upstream) |
|---|---|---|
| DMI | `83E1` / `Legion Go 8APU1` | `83N0`, `83N1` / `83L3`, `83N6`, `83Q2`, `83Q3` |
| CPU | AMD Ryzen Z1 Extreme (Phoenix) | Z2 Extreme / Z1E / Z2 Go |
| Диапазон прошивки | **5–30 / 32 / 41 Вт** | 35/37/45 (Go 2), 40/43/53 (Go S) |
| Бэкенды | firmware-attributes → **acpi_call** → ryzenadj | firmware-attributes → ryzenadj |
| Extras (разблокировка) | до 40 Вт, только через ryzenadj | до 50 Вт |

Профили устройств не смешиваются: Go 1, Go 2, Go S Z1 Extreme и Go S Z2 Go —
четыре разные записи в таблице, каждая со своими значениями.

---

## Бэкенды: как выбирается и почему

Плагин при старте проверяет всё три пути и берёт первый доступный.

**1. Lenovo firmware attributes (`wmi`) — предпочтительный**

`/sys/class/firmware-attributes/lenovo-wmi-other-*/attributes/{ppt_pl1_spl,ppt_pl2_sppt,ppt_pl3_fppt}`
плюс `platform-profile`, у которого в `choices` есть `custom`.

Это in-kernel драйвер `lenovo-wmi-other` (мейнлайн с Linux 6.17). Он публикует
`min_value` / `max_value` для каждого параметра — то есть **реальный диапазон
читается из прошивки, а не угадывается**. Прошивка принимает запись только пока
активен профиль `custom`, поэтому плагин переводит платформу в него перед
записью.

**2. Lenovo firmware через `acpi_call` (`acpi`)**

Тот же самый интерфейс прошивки, но через `/proc/acpi/call`, когда драйвера в
ядре нет (SteamOS 3.7 = Linux 6.11). Именно так работает Handheld Daemon на
Legion Go 1:

```
\_SB.GZFD.WMAA 0x00 0x2C 0xFF          # включить custom power mode
\_SB.GZFD.WMAE 0x00 0x12 <id><value>   # записать SPL / SPPT / FPPT
\_SB.GZFD.WMAE 0x00 0x11 <id>          # прочитать обратно
```

`id = device<<24 | feature<<16 | mode<<8 | type` — SPL `0x0102FF00`,
SPPT `0x0101FF00`, FPPT `0x0103FF00` (совпадает с
`drivers/platform/x86/lenovo/wmi-other.c`). Каждая запись проверяется чтением.

Ограничение: диапазон здесь прошивка не публикует (capability data лежит за
отдельным WMI data block), поэтому используется документированный диапазон
Go 1 — 5–30 / 32 / 41 Вт, и любое «прошивка обрезала значение» видно по
read-back и попадает в лог.

**3. `ryzenadj` — только когда прошивка недоступна**

На стоковой SteamOS без `acpi_call` и без драйвера это единственный работающий
путь, поэтому он остаётся. Он же используется для Extras-диапазона и как
перекрёстная проверка (живое чтение SMU против того, что рапортует прошивка).

Плагин **не** ставит ryzenadj «просто потому что он есть»: на Go S он вообще не
скачивается, а на Go 1 firmware-путь всегда идёт первым.

---

## Пресеты Legion Go 1

Значения подобраны под режимы самой Lenovo (quiet 8 Вт, balanced 15 Вт,
performance 20 Вт, custom до 30 Вт), а не скопированы с Go 2:

| Пресет | SPL | SPPT | FPPT |
|---|---|---|---|
| Minimum | 5 | 7 | 10 |
| Silent | 8 | 10 | 14 |
| Balanced | 15 | 17 | 22 |
| Performance | 20 | 22 | 28 |
| Max | 30 | 32 | 41 |
| Custom | ползунки 5 … (максимум прошивки) | | |

Если прошивка сообщает свой диапазон (бэкенд `wmi`), пресеты и ползунки
дополнительно обрезаются по нему — на экране не может оказаться значение,
которое железо не примет.

---

## Возможности

- Пресеты Minimum / Silent / Balanced / Performance / Max + Custom.
- Ручные ползунки SPL / SPPT / FPPT с гарантией `SPL ≤ SPPT ≤ FPPT`.
- **Профиль на игру** — применяется автоматически при запуске, глобальные
  настройки возвращаются после выхода.
- **Раздельные профили Battery / AC** — и глобально, и для каждой игры.
- **Drift correction** — если прошивка или другая программа увела лимиты,
  плагин возвращает их обратно; после нескольких неудачных попыток он
  останавливается и не воюет с железом бесконечно (на Go 1 BIOS сам снижает TDP
  при перегреве — это защита, а не сбой).
- **Charger transition** — при подключении зарядки прошивка Legion Go
  применяет свой профиль с задержкой, поэтому значение переприменяется по
  лестнице 0.5 / 1.5 / 3 / 6 / 10 с, пока не закрепится.
- **Suspend/resume** — лимиты возвращаются сразу по уведомлению Steam.
- **Current TDP** — отдельно «TDP limit (SPL)» (что установлено) и отдельно
  «Current package power» (сколько реально потребляет пакет, из RAPL).
- **Diagnostics** — прямо в панели: устройство, CPU, BIOS, ядро, активный
  бэкенд, доступность каждого бэкенда, диапазоны и их источник, текущие
  значения, режим прошивки, найденные конфликты.
- **Предупреждение о конфликтах** — hhd / adjustor / PowerStation /
  SimpleDeckyTDP / PowerControl / upstream LeGoTDP.

---

## Установка на SteamOS

Нужен установленный [Decky Loader](https://decky.xyz).

1. Скопируйте `LeGoTDP-LegionGo1-1.0.0.zip` на консоль (флешка, `scp`, Steam
   Downloads — любым способом).
2. Gaming Mode → **Steam (⋯) → Decky → значок шестерёнки → Developer**.
3. **Install Plugin from ZIP** → выберите файл.
4. Decky перезапустит плагин; в Quick Access Menu появится **LeGoTDP-LegionGo1**.

Если раньше стоял upstream **LeGoTDP** — удалите его (Decky → Developer →
Uninstall). Два плагина, управляющих одними и теми же тремя лимитами, будут
перезаписывать друг друга.

Первый запуск при наличии сети скачивает проверенный по SHA-256 `ryzenadj`
(~2 МБ). Без сети плагин всё равно работает, если доступен firmware-путь.

### Проверка после установки

```bash
# в Desktop Mode или по ssh
sudo journalctl -u plugin_loader -n 100 --no-pager | grep legotdp
```

Строка `ready on Lenovo Legion Go 1 (Z1 Extreme): backend=...` скажет, какой
бэкенд выбран и какой диапазон определён.

---

## Диагностический скрипт

Скрипт лежит внутри установленного плагина:

```bash
cd /home/deck/homebrew/plugins/LeGoTDP-LegionGo1/scripts
chmod +x legiongo1-diagnostics.sh
sudo ./legiongo1-diagnostics.sh
```

Он печатает: DMI-модель, версию BIOS, версию ядра, состояние модулей
`lenovo_wmi_*` и `acpi_call`, все firmware-атрибуты с min/max/current,
platform profile и его choices, ответ GameZone через acpi_call, наличие
ryzenadj, RAPL-потребление, конфликтующие процессы и плагины — и в конце
вывод: **какой бэкенд будет использован и почему**.

Проверка записи (меняет TDP на несколько секунд и возвращает как было; в конце
ещё и спрашивает у прошивки заведомо завышенное значение, чтобы узнать её
настоящий потолок):

```bash
sudo ./legiongo1-diagnostics.sh --write-test
```

---

## Что проверить на реальном Legion Go 1

Порт нельзя считать проверенным, пока на железе не пройдены все пункты:

1. TDP меняется (пресет и ползунок).
2. Значение действительно применилось — `Diagnostics → Currently set` и
   `--write-test` показывают то же, что выбрано.
3. Через 30–60 секунд значение не сбросилось.
4. Значение не сбросилось после запуска игры.
5. Профиль игры применяется автоматически.
6. После выхода из игры вернулись глобальные настройки.
7. Переключение AC/Battery работает (в обе стороны).
8. Suspend/resume не ломает TDP.
9. Подключение зарядки не сбрасывает TDP (следите за лестницей re-settle).
10. Gaming Mode работает стабильно, в `journalctl` нет ошибок `[legotdp]`.

Тесты, которые нужно запустить на самом устройстве (они пропускаются, если
железо не отвечает):

```bash
cd /home/deck/homebrew/plugins/LeGoTDP-LegionGo1
sudo LEGOTDP_PLUGIN_DIR=$PWD python -m unittest discover -s tests -t tests
```

---

## Сборка из исходников

```bash
npm install
npm run typecheck
npm run build
npm run package     # -> LeGoTDP-LegionGo1-<version>.zip
python -m unittest discover -s tests -t tests
```

---

## Совместимость и конфликты

Не запускайте одновременно с другими регуляторами TDP:

- **Handheld Daemon (hhd / adjustor)** — использует тот же `acpi_call`-путь.
- **SimpleDeckyTDP**, **PowerControl** — те же firmware-атрибуты или ryzenadj.
- **Ползунок TDP самого SteamOS** (если в вашей версии он активен на Go 1) —
  пишет в те же firmware-атрибуты.
- **upstream LeGoTDP** — другая таблица устройств.

Плагин их обнаруживает и показывает предупреждение, но не блокирует: выбор за
вами. Ничего из этого не приводит к поломке — только к тому, что лимиты будут
перезаписываться туда-сюда.

## Безопасность

Основной предел — тот, который сообщает прошивка. Ползунки не выходят за него,
пока пользователь явно не включит **Extras** (и это возможно только при
доступном ryzenadj). Потолок Extras для Go 1 — 40 Вт, а не 50, как у Go 2:
у этого корпуса другое охлаждение, и смысл переключателя — запас, а не цифра.

---

## Лицензия и благодарности

BSD 3-Clause, см. `LICENSE` и `NOTICE`.

- Оригинальный LeGoTDP — [Rayekkk](https://github.com/Rayekkk/LeGoTDP).
- Интерфейс прошивки Legion Go описан по
  [hhd-dev/adjustor](https://github.com/hhd-dev/adjustor) и драйверам
  `drivers/platform/x86/lenovo/` в мейнлайн-ядре (Derek J. Clark).
- Практика по Legion Go на Linux —
  [aarron-lee/legion-go-tricks](https://github.com/aarron-lee/legion-go-tricks)
  и [SimpleDeckyTDP](https://github.com/aarron-lee/SimpleDeckyTDP).
- RyzenAdj — [FlyGoat/RyzenAdj](https://github.com/FlyGoat/RyzenAdj) (LGPL-3.0,
  скачивается на устройстве, в архив не входит).
